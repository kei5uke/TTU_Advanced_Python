# ICS0019 Homework1  
## Find Are of Triangle  
*/triangle_kekonn* include the main application.  
*/test* includes test cases  
Install tkinter by using this command below   
```
sudo apt-get install python3-tk 
```
If you are mac user  
```
brew install python3-tk
```
